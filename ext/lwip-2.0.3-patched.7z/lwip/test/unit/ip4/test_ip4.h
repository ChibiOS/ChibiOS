#ifndef LWIP_HDR_TEST_IP4_H
#define LWIP_HDR_TEST_IP4_H

#include "../lwip_check.h"

Suite* ip4_suite(void);

#endif
