/*
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _PICO_LLVM_LIBC_SYS_STAT_H
#define _PICO_LLVM_LIBC_SYS_STAT_H

typedef int off_t;

struct stat {};

#endif
