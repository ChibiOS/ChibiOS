/*
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// new location; this file kept for backwards compatibility
#include "boot/bootrom_constants.h"
