var structnetif__ext__callback__args__t_1_1status__changed__s =
[
    [ "state", "structnetif__ext__callback__args__t_1_1status__changed__s.html#a207d3afdf0a37d16a61d1253e264d7a7", null ]
];