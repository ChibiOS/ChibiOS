var structmdns__packet =
[
    [ "answers", "structmdns__packet.html#a918feee242cfb3934d9f5c3de1c298e7", null ],
    [ "answers_left", "structmdns__packet.html#a56ba495a1458a21982e65d746468849d", null ],
    [ "netif", "structmdns__packet.html#ac7307f344f654cb954f92d578dc7c989", null ],
    [ "parse_offset", "structmdns__packet.html#a4c3c3a28ac113b3ee40d5cf07d851f68", null ],
    [ "pbuf", "structmdns__packet.html#a2ec02a67fd82f0df695e94745eddaf45", null ],
    [ "questions", "structmdns__packet.html#a09211e78f7f773c492b5856d31423699", null ],
    [ "questions_left", "structmdns__packet.html#afdb9c14dd0c915119b8adb584381a437", null ],
    [ "recv_unicast", "structmdns__packet.html#a8659b4f582be0df84b6ae91308737377", null ],
    [ "source_addr", "structmdns__packet.html#aaa64cc21495dc6bb76ed9125904dd07a", null ],
    [ "tx_id", "structmdns__packet.html#a0cd71fd9af6d2529e6a41c451c037e00", null ]
];