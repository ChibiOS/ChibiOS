var group__apps =
[
    [ "HTTP client", "group__httpc.html", "group__httpc" ],
    [ "HTTP server", "group__httpd.html", "group__httpd" ],
    [ "Iperf server", "group__iperf.html", "group__iperf" ],
    [ "MDNS", "group__mdns.html", "group__mdns" ],
    [ "MQTT client", "group__mqtt.html", "group__mqtt" ],
    [ "NETBIOS responder", "group__netbiosns.html", "group__netbiosns" ],
    [ "SMTP client", "group__smtp.html", "group__smtp" ],
    [ "SNMPv2c/v3 agent", "group__snmp.html", "group__snmp" ],
    [ "SNTP", "group__sntp.html", "group__sntp" ],
    [ "TFTP server", "group__tftp.html", "group__tftp" ]
];