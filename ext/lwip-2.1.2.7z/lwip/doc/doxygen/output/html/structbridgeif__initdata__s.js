var structbridgeif__initdata__s =
[
    [ "ethaddr", "structbridgeif__initdata__s.html#a8e0048db5e021f5d79411492dc9330bc", null ],
    [ "max_fdb_dynamic_entries", "structbridgeif__initdata__s.html#aeb312c2e698513c6416d5c8459ad622f", null ],
    [ "max_fdb_static_entries", "structbridgeif__initdata__s.html#a210915aa1b0436ccabc7e8d9fd3c3fe6", null ],
    [ "max_ports", "structbridgeif__initdata__s.html#a0e0bb6a885967b5fcfef09a8f0adc63f", null ]
];