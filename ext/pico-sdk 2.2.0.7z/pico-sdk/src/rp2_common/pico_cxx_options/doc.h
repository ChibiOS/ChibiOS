/**
 * \defgroup pico_cxx_options pico_cxx_options
 * \brief non-code library controlling C++ related compile options
 */
